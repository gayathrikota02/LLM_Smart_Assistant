# full_agent_rich.py
import os
import sys
import re
import json
from datetime import datetime
from pathlib import Path
from dotenv import load_dotenv
from rich.console import Console
from rich.panel import Panel

from calculator_tool import calculate
from translator_tool import translate
import google.generativeai as genai

# ---------------- Setup ----------------
load_dotenv()
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
MODEL = "gemini-1.5-flash"

console = Console()
BASE_DIR = Path(__file__).parent
LOG_DIR = BASE_DIR / "logs"
LOG_DIR.mkdir(exist_ok=True)
LOG_FILE = LOG_DIR / "level3_interaction.log"

SYSTEM_RULES = (
    "You are a helpful tutor agent.\n"
    "You can use tools (calculator, translator).\n"
    "Always break queries into steps like Step 1, Step 2.\n"
    "If a query has multiple tasks, solve them step by step and combine results.\n"
)

# ---------------- Helper Functions ----------------
def is_math_query(q: str) -> bool:
    return any(word in q.lower() for word in [
        "add", "plus", "+", "multiply", "times", "*",
        "subtract", "minus", "divide", "/", "by", "sqrt", "squareroot", "square root", "power", "^"
    ]) or bool(re.search(r"\d+\s*[\+\-\/\*]\s\d+", q))

def split_math_steps(expression: str):
    pattern = re.compile(
        r'(?:'
        r'add\s+\d+\.?\d*\s+(?:and|to)\s+\d+\.?\d*|'
        r'subtract\s+\d+\.?\d*\s+(?:and|from)\s+\d+\.?\d*|'
        r'multiply\s+\d+\.?\d*\s+(?:and|by)\s+\d+\.?\d*|'
        r'divide\s+\d+\.?\d*\s+(?:and|by)\s+\d+\.?\d*|'
        r'square\s+root\s+of\s+\d+\.?\d*|'
        r'squareroot\s+of\s+\d+\.?\d*|'
        r'sqrt\(\d+\.?\d*\)|'
        r'\d+\.?\d*\s*\^\s*\d+\.?\d*|'
        r'\d+\.?\d*\s*[\+\-\/\*]\s\d+'
        r')', re.IGNORECASE)
    return [m.strip() for m in pattern.findall(expression) if m.strip()]

def call_llm(question: str) -> str:
    model = genai.GenerativeModel(MODEL)
    response = model.generate_content(SYSTEM_RULES + "\nUser: " + question)
    return response.text.strip()

def save_log(question: str, answer: str):
    record = {"timestamp": datetime.utcnow().isoformat()+"Z", "question": question, "answer": answer}
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")

# ---------------- Agent Executor ----------------
def agentic_executor(query: str) -> str:
    steps = []
    step_num = 1

    # Normalize "and then" -> "then"
    query = re.sub(r'\band\s+then\b', ' then ', query, flags=re.IGNORECASE)
    split_pattern = r"\b(?:then|and(?=\s*(?:translate|multiply|add|subtract|divide|what|tell|who|where|how|when|is|are|does|do)))\b"
    raw_parts = [p.strip() for p in re.split(split_pattern, query, flags=re.IGNORECASE) if p.strip()]

    for part in raw_parts:
        part_lower = part.lower()
        # Translation
        if "translate" in part_lower:
            match = re.search(
                r"translate\s+'(.+?)'\s+(?:into|to)\s+(\w+)|translate\s+'(.+?)'\s+from\s+(\w+)\s+to\s+(\w+)",
                part, re.IGNORECASE
            )
            if match:
                if match.group(1) and match.group(2):
                    text, target_lang = match.group(1), match.group(2)
                else:
                    text, target_lang = match.group(3), match.group(5)
                lang_codes = {"german":"de","french":"fr","spanish":"es","italian":"it",
                              "japanese":"ja","hindi":"hi","telugu":"te","tamil":"ta","english":"en"}
                code = lang_codes.get(target_lang.lower(), "de")
                result = translate(text, target_lang=code)
                steps.append(f"Step {step_num}: Translate '{text}' → {result}")
                step_num += 1
            else:
                result = call_llm(part)
                steps.append(f"Step {step_num}: LLM answer → {result}")
                step_num += 1
        # Math
        elif is_math_query(part):
            math_parts = split_math_steps(part) or [part]
            for m in math_parts:
                result = calculate(m)
                steps.append(f"Step {step_num}: Solve math → {result}")
                step_num += 1
        # General LLM
        else:
            result = call_llm(part)
            steps.append(f"Step {step_num}: LLM answer → {result}")
            step_num += 1

    return "\n".join(steps)

# ---------------- Main ----------------
def main():
    if len(sys.argv) < 2:
        console = Console()
        console.print("[red]Usage: python full_agent_rich.py \"Your question here\"[/red]")
        sys.exit(1)

    query = sys.argv[1]
    answer = agentic_executor(query)

    # Rich panel with green border
    console = Console()
    console.print(Panel(answer, title="Assistant", border_style="green"))

    # Log
    save_log(query, answer)
    console.print(f"[dim]Appended to log → {LOG_FILE}[/dim]")

if __name__ == "__main__":
    main()
