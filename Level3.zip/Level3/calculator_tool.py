import re
import math

def calculate(question: str) -> str:
    """
    
    Handles simple arithmetic in symbol or word form.
    Supports: add, subtract, multiply,square root (sqrt or squareroot), power/exponent (^ or 'power of'), divide
     Supports multiple operations separated by 'and' or ';'.
    Returns results sequentially.
    Examples:
      "12 * 7" -> "84"
      "add 45 and 30" -> "75"
      "multiply 2 and 5" -> "10"
      "subtract 2 from 5" -> "3"
      "divide 10 by 2" -> "5"
    """

    q = question.lower().strip()
    numbers = list(map(float, re.findall(r'\d+\.?\d*', q)))

    # --- Square root (needs only 1 number) ---
    if any(word in q for word in ["square root", "squareroot", "sqrt"]):
        if len(numbers) == 1:
            return str(math.sqrt(numbers[0]))
        return "Square root expects exactly one number."

    # --- Power / Exponent ---
    if "power" in q or "^" in q:
        if len(numbers) == 2:
            return str(numbers[0] ** numbers[1])
        return "Power operation expects two numbers."

    # --- Basic arithmetic (2 numbers required) ---
    if len(numbers) != 2:
        return "Sorry, I can only handle operations with 2 numbers like '12 * 7' or 1 number for sqrt."

    a, b = numbers

    if any(word in q for word in ["multiply", "times", "product"]):
        return str(a * b)
    elif any(word in q for word in ["divide", "quotient", "by"]):
        return str(a / b)
    elif any(word in q for word in ["add", "plus", "sum"]):
        return str(a + b)
    elif any(word in q for word in ["subtract", "minus", "difference"]):
        if "from" in q:
            return str(b - a)
        return str(a - b)
    else:
        # fallback for symbols
        expr = re.sub(r"[^\d\+\-\*/\^xX\. ]", "", question)
        try:
            return str(eval(expr.replace("^", "**"), {"__builtins__": {}}))
        except Exception:
            return "Sorry, I can only handle simple arithmetic like '12 * 7'."
