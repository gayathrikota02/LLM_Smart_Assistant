# chatbot_gemini.py
import os
import json
import re
import argparse
import datetime

from pathlib import Path
from dotenv import load_dotenv
import google.generativeai as genai
from rich.console import Console
from rich.panel import Panel

console = Console()
load_dotenv()

# --- config ---
MODEL = "gemini-1.5-flash"


# Always point to Level1/logs (relative to this script)
BASE_DIR = Path(__file__).parent   # -> Level1/
LOG_DIR = BASE_DIR / "logs"
LOG_DIR.mkdir(exist_ok=True)

LOG_FILE = LOG_DIR / "level1_interaction.log"

SYSTEM_PROMPT = """\
You are a teaching assistant who ALWAYS explains STEP-BY-STEP with a crisp structure.

Style guide:
- Start with: "Let's think step by step:"
- Use a short numbered list (2–8 lines).
- End with a brief "Final answer:" summary (1–2 sentences).
- Keep tone clear and friendly.

VERY IMPORTANT (Level 1 rules):
- If the user asks for an arithmetic calculation (e.g., 15 + 23, 12 * 7, 45 and 30 added),
  you MUST REFUSE to compute and instead say:
  "I can’t calculate directly in Level 1. Hint: we’ll add a calculator tool in Level 2."
- Do NOT include any numeric result when refusing.
"""

# regex to detect math-like questions
MATH_REGEX = re.compile(r"""
    (?:
        \d+\s*[\+\-\*/xX]\s*\d+        # 12+7, 9 x 8, etc.
        |
        (add|plus|sum|subtract|minus|difference|multiply|times|product|divide|quotient)\b
    )
""", re.IGNORECASE | re.VERBOSE)

def is_probably_math(q: str) -> bool:
    return bool(MATH_REGEX.search(q))

def ask_gemini(question: str) -> str:
    genai.configure(api_key=os.environ.get("GEMINI_API_KEY"))
    model = genai.GenerativeModel(MODEL)

    # prepend system instruction
    full_prompt = SYSTEM_PROMPT + "\n\nUser question: " + question

    response = model.generate_content(full_prompt)
    return response.text.strip()

def log_interaction(question: str, answer: str, log_file: Path) -> None:
    payload = {
        "timestamp": datetime.datetime.now().isoformat(),
        "level": "level_1_gemini",
        "question": question,
        "answer": answer,
    }
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(json.dumps(payload, ensure_ascii=False) + "\n")

def main():
    parser = argparse.ArgumentParser(description="Level 1 — Gemini Smart Assistant")
    parser.add_argument("question", nargs="*", help="Your question (put in quotes)")
    parser.add_argument("--no-log", action="store_true", help="Do not write interaction logs")
    args = parser.parse_args()

    question = " ".join(args.question) if args.question else input("Your question: ").strip()
    if not question:
        console.print("[red]Please enter a question.[/red]")
        return

  
    try:
        answer = ask_gemini(question)
    except Exception as e:
        console.print(Panel.fit(str(e), title="Gemini API Error", border_style="red"))
        return

    console.print(Panel(answer, title="Assistant", border_style="green"))

    if not args.no_log:
        log_interaction(question, answer, LOG_FILE)
        console.print(f"[dim]Appended to log → {LOG_FILE}[/dim]")

if __name__ == "__main__":
    main()
