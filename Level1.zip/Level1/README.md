# Level 1 – Easy: LLM-only Chatbot



A simple Python command-line assistant using **Gemini 1.5 Flash**.  
Focus: **Prompt engineering** to provide **step-by-step explanations** while **refusing direct arithmetic calculations** (Level 1 rule).



## Features

- Explains answers in **short numbered steps**.
- Provides a **friendly, structured response**.
- **Refuses arithmetic calculations**, hinting at Level 2 calculator tool.
- Logs all interactions in `logs/level1_interaction.log`.


## Requirements

- Python 3.10+
- [Gemini API Key](https://developers.generativeai.google/) stored in `.env` as `GEMINI_API_KEY`
- Install dependencies:

```bash
pip install -r requirements.txt


## Dependencies include:

- google-generativeai
- rich
- python-dotenv

## Usage

- CLI Mode

Ask a question directly:

python chatbot.py "What are the colors in a rainbow?"


## Interactive Mode
python chatbot.py


## Level 1 Rules

Always start responses with:
"Let's think step by step:"

Use 2–8 numbered steps.

End with a brief "Final answer:" summary.

Refuse arithmetic calculations (e.g., 15 + 23, 12 * 7), e.g.:

"I can’t calculate directly in Level 1. Hint: we’ll add a calculator tool in Level 2."


### Logs

- All interactions are saved in:

logs/level1_interaction.log


- Each entry contains:

Timestamp
Question
Assistant answer


### Example 1:

python Level1/chatbot.py "Why do leaves change color in autumn?"

╭────────────────────────────────────────── Assistant ──────────────────────────────────────────╮
│ Let's think step by step:                                                                     │
│                                                                                               │
│ 1.  Chlorophyll, the green pigment in leaves, is essential for photosynthesis (making food    │
│ from sunlight).                                                                               │
│ 2.  As days get shorter and colder in autumn, there's less sunlight.                          │
│ 3.  Trees begin to slow down their food-making process.                                       │
│ 4.  The chlorophyll breaks down, revealing other pigments that were already present in the    │
│ leaf.                                                                                         │
│ 5.  These other pigments, like carotenoids (yellows and oranges) and anthocyanins (reds and   │
│ purples), become visible.                                                                     │
│ 6.  The leaves eventually lose their connection to the tree branch (abscission).              │
│ 7.  The leaves then fall to the ground.                                                       │
│ 8.  The change in color is a natural process preparing the tree for winter dormancy.          │
│                                                                                               │
│                                                                                               │
│ Final answer:  The color change in autumn leaves is due to the breakdown of chlorophyll,      │
│ revealing other pigments already present and the tree preparing for winter.                   │
╰───────────────────────────────────────────────────────────────────────────────────────────────╯



### Example 2:

python Level1/chatbot.py "What is 100 minus 25?"

╭────────────────────────────────────────── Assistant ──────────────────────────────────────────╮
│ Let's think step by step:                                                                     │
│                                                                                               │
│ 1. We are asked to find the difference between 100 and 25.                                    │
│ 2. This is a subtraction problem.                                                             │
│ 3. We start with the larger number, 100.                                                      │
│ 4. We need to subtract the smaller number, 25, from it.                                       │
│ 5.  This means finding out how much is left when we take 25 away from 100.                    │
│ 6. I can’t calculate directly in Level 1. Hint: we’ll add a calculator tool in Level 2.       │
│                                                                                               │
│ Final answer:  To solve this, you would perform the subtraction 100 - 25.  A calculator will  │
│ be helpful in Level 2.                                                                        │
╰───────────────────────────────────────────────────────────────────────────────────────────────╯


