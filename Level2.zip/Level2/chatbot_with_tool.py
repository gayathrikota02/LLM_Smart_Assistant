# chatbot_with_tool.py

import os
import sys
import re
import json
from datetime import datetime
from pathlib import Path
import google.generativeai as genai
from dotenv import load_dotenv
from rich.console import Console
from rich.panel import Panel
from calculator_tool import calculate


# ---------------- Setup ----------------
load_dotenv()
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
MODEL = "gemini-1.5-flash"

console = Console()
BASE_DIR = Path(__file__).parent   # -> Level2/
LOG_DIR = BASE_DIR / "logs"
LOG_DIR.mkdir(exist_ok=True)
LOG_FILE = LOG_DIR / "level2_interaction.log"

SYSTEM_PROMPT = (
    "You are a helpful tutor.\n"
    "Always answer with two sections:\n"
    "Answer:\n"
    "Steps:\n"
    "For every knowledge question, break your explanation into short steps like Step 1, Step 2, Step 3 in short and consise manner.\n"
    "For math-only questions, let the calculator tool handle them. eg: 12 times 7 \n"
    "If the user asks for multiple things (math + knowledge), reply:Sorry, I can only handle one type of request at a time in Level 2."

)

MATH_REGEX = re.compile(
    r"\d+\s*[\+\-\*/xX]\s*\d+|(add|plus|sum|subtract|minus|multiply|times|divide|x)\s+\d+",
    re.IGNORECASE
)

# ---------------- Functions ----------------
def is_math_only(q: str) -> bool:
    q = q.lower()
    # Symbol-based math like 12 * 7
    if re.search(r"\d+\s*[\+\-\*/xX]\s*\d+", q):
        return True
    # Word-based math like add/subtract/multiply/divide
    if re.search(r"(add|plus|sum|subtract|minus|multiply|times|divide|x)\s+\d+", q):
        return True
    return False

def is_mixed_task(q: str) -> bool:
    """
    Detect multi-step tasks: math + separate knowledge request.
    Ignore 'and' connecting numbers in math expressions.
    """
    q_lower = q.lower()

    if not is_math_only(q_lower):
        return False

    # Remove math expressions
    math_pattern = r"(\d+\s*[\+\-\*/xX]\s*\d+|(add|plus|sum|subtract|minus|multiply|times|divide|x)\s+\d+)"
    q_no_math = re.sub(math_pattern, "", q_lower)

    # Remove filler words
    q_no_math = re.sub(r"\b(and|by|from|what|is|calculate|result|please|give|me|the|of)\b", "", q_no_math)

    # Remove extra spaces/punctuation
    q_no_math = re.sub(r"[^a-z]", " ", q_no_math).strip()

    # If still contains letters → it’s truly mixed
    return bool(q_no_math)




def call_gemini(question: str) -> str:
    model = genai.GenerativeModel(MODEL)
    response = model.generate_content(SYSTEM_PROMPT + "\nUser: " + question)
    return response.text.strip()

def log_interaction(question: str, answer: str):
    record = {
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "question": question,
        "answer": answer
    }
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")

# ---------------- Main ----------------
def main():
    if len(sys.argv) < 2:
        console.print("[red]Usage: python chatbot_with_tool.py \"Your question here\"[/red]")
        sys.exit(1)

    question = sys.argv[1]

    # Determine type
    if is_mixed_task(question):
        answer = "I can’t do multi-step tasks yet (math + knowledge). Please ask one thing at a time."
    elif is_math_only(question):
        result = calculate(question)
        answer = f"The result is: {result}"
    else:
        answer = call_gemini(question)

    # Display
    console.print(Panel(answer, title="Assistant", border_style="green"))

    # Log
    log_interaction(question, answer)
    console.print(f"[dim]Appended to log → {LOG_FILE}[/dim]")

if __name__ == "__main__":
    main()
