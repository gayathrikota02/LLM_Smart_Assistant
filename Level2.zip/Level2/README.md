# Level 2 — MEDIUM: LLM + Basic Tool

A Python command-line assistant using **Gemini 1.5 Flash**, extended with a **calculator tool** for arithmetic operations.

---

## Features

- Detects **simple arithmetic questions** and uses a calculator tool (does not calculate directly in LLM).  
- Provides **step-by-step explanations** for normal queries.  
- Gracefully handles multi-step queries with a friendly message.  
- Logs all interactions in `logs/level2_interaction.log`.  
- Supports **CLI mode** and **interactive mode**.  

---

## Requirements

- Python 3.10+  
- [Gemini API Key](https://developers.generativeai.google/) stored in `.env` as `GEMINI_API_KEY`  


- Install dependencies:

```bash
pip install -r requirements.txt

## Dependencies include:

- google-generativeai
- rich
- python-dotenv


## Usage
CLI Mode

Ask a question directly:

Level2/python chatbot_with_tool.py "What is 12 * 7?"


## Level 2 Rules

- Step-by-step explanations are provided for normal questions.

- Single-step arithmetic is detected and calculated using the calculator tool.

- Multi-step or combined queries are not handled yet (graceful failure).

- Logs are appended to logs/level2_interaction.log.


## Example Interactions
1. python Level2/chatbot_with_tool.py "What is 50 plus 25?"

╭────────────────────────────────────────── Assistant ──────────────────────────────────────────╮
│ The result is: 25.0                                                                           │
╰───────────────────────────────────────────────────────────────────────────────────────────────╯

2. python Level2/chatbot_with_tool.py "Multiply 9 and 8, and also tell me the capital of Japan." 

╭────────────────────────────────────────── Assistant ──────────────────────────────────────────╮
│ I can’t do multi-step tasks yet (math + knowledge). Please ask one thing at a time.           │
╰───────────────────────────────────────────────────────────────────────────────────────────────╯