# calculator_tool.py
import re

def calculate(question: str) -> str:
    """
    
    Handles simple arithmetic in symbol or word form.
    Supports: add, subtract, multiply, divide
     Supports multiple operations separated by 'and' or ';'.
    Returns results sequentially.
    Examples:
      "12 * 7" -> "84"
      "add 45 and 30" -> "75"
      "multiply 2 and 5" -> "10"
      "subtract 2 from 5" -> "3"
      "divide 10 by 2" -> "5"
    """
    q = question.lower()
    numbers = list(map(float, re.findall(r'\d+\.?\d*', q)))

    if len(numbers) != 2:
        return "Sorry, I can only handle simple arithmetic like '12 * 7' or '45 + 30'."

    a, b = numbers

    if any(word in q for word in ["multiply", "times", "product"]):
        return str(a * b)
    elif any(word in q for word in ["divide", "quotient", "by"]):
        return str(a / b)
    elif any(word in q for word in ["add", "plus", "sum"]):
        return str(a + b)
    elif any(word in q for word in ["subtract", "minus", "difference"]):
        if "from" in q:
            return str(b - a)
        return str(a - b)
    else:
        # fallback for symbols
        expr = re.sub(r"[^\d\+\-\*/xX\. ]", "", question)
        try:
            return str(eval(expr, {"__builtins__": {}}))
        except Exception:
            return "Sorry, I can only handle simple arithmetic like '12 * 7' or '45 + 30'."
